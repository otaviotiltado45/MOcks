import { validateCharacter, performAttack } from '../characterFunctions'; 

describe('validateCharacter', () => {
  test('Validar personagem com nome vazio', () => {
    const character = {
      nome: '',
      vida: 1500,
      defesa: 100,
      forca: 200,
    };
    expect(validateCharacter(character)).toBe(false);
  });


});

describe('performAttack', () => {
  const mockValidateCharacterSuccess = jest.fn((character) => true);
  const mockValidateCharacterFail = jest.fn((character) => false);

  test('Ataque entre dois personagens válidos', () => {
    const attacker = {
      nome: 'Atacante',
      vida: 1500,
      defesa: 100,
      forca: 200,
    };
    const defender = {
      nome: 'Defensor',
      vida: 1500,
      defesa: 150,
      forca: 100,
    };

    performAttack(attacker, defender, mockValidateCharacterSuccess);

    expect(defender.vida).toBe(1300); // 1500 - (200 - 150) = 1300
  });

  test('Ataque com personagem inválido', () => {
    const attacker = {
      nome: 'Atacante',
      vida: 1500,
      defesa: 100,
      forca: 200,
    };
    const defender = {
      nome: 'Defensor',
      vida: 1500,
      defesa: 150,
      forca: -100, // Personagem inválido
    };

    const errorMessage = performAttack(attacker, defender, mockValidateCharacterFail);

    expect(errorMessage).toBe('Invalid Character');
  });

  // Adicione mais testes aqui para cada caso que você deseja testar
});
