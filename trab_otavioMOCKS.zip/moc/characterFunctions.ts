interface Character {
    nome: string;
    vida: number;
    defesa: number;
    forca: number;
  }
  
  export function validateCharacter(character: Character): boolean {
    if (
      character.nome.trim() === '' ||
      character.vida <= 0 ||
      character.defesa <= 0 ||
      character.forca <= 0
    ) {
      return false;
    }
    return true;
  }
  
  export function performAttack(attacker: Character, defender: Character, validator: Function): void | string {
    if (!validator(attacker) || !validator(defender)) {
      return 'Invalid Character';
    }
  
    const damage = attacker.forca - defender.defesa;
    if (damage > 0) {
      defender.vida -= damage;
    }
  }
  